<?php

$base = "/System/Library/CoreServices/CoreTypes.bundle/Contents/Resources/";
$icons = scandir( $base );

if ( ! file_exists( __DIR__ . "/images" ) )
	mkdir( __DIR__ . "/images", 0775, TRUE );
$out = '<html><head></head><body><ul>';
foreach ( $icons as $icon ) {
	if ( preg_match( "/([A-Za-z0-9-]{1,})\.icns$/", $icon, $matches ) ) {
		$out .= "<li><div class='icon-message'>{$matches[1]}</div><div class='icon'><img src='images/{$matches[1]}.png'</div></li>";
		if ( ! file_exists( __DIR__ . "/images/{$matches[1]}.png" ) ) {
			exec( "sips -s format png '{$base}/{$icon}' --out 'images/{$matches[1]}.png'" );
			exec( "sips -z 128 128 images/{$matches[1]}.png" );
		}
	}
}
$out .= "</ul></body>";
file_put_contents( 'system.html', $out );
?>

