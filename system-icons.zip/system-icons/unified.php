<?php

$root = scandir( '.' );
foreach ( $root as $file ) :
	if ( is_dir( $file ) && ( strpos( $file, 'System Icons --' ) !== FALSE ) )
		$dirs[] = $file;
endforeach;

foreach( $dirs as $dir ) :
	if ( file_exists( "{$dir}/images" ) && is_dir( "{$dir}/images" ) ) {
		$images = array_diff( scandir( "{$dir}/images" ), array( '.DS_Store', '.', '..' ) );
		foreach ( $images as $image ) :
			$os = str_replace( 'System Icons -- ', '', $dir );
			$unified[ $image ][] = $os;
		endforeach;
	}
endforeach;

ksort( $unified, SORT_NATURAL | SORT_FLAG_CASE );

$out = "
<html>
<head>
<style>
table {
	max-width:60%;
	position: relative;
	margin:0 auto;
}
body {
	text-align: center;
	font-family: sans-serif;
}
td {
	margin: 5px;
	padding:5px;
	border: 1px solid gray;
}
tr {
	margin: 5px;
	opacity: .5;
}
.nil {
	text-align: center;
	background: #ccc;
}
.eligible {
	opacity: 1;
}
ol {
	text-align: left;
}
</style>
</head>
<body>
<table>
<tr><th>Icon</th><th>10.8</th><th>10.9</th><th>10.10</th></tr>
";
$all = array();
foreach ( $unified as $icon => $versions ) :
	// For some reason the conversion script created a lot of icons with ._ prefaced.
	if ( strpos( $icon, "._" ) === 0 )
		continue;

	if ( count( $versions ) == 3 ) {
		$all[] = $icon;
	$out .= "
<tr class = 'eligible'>";
	} else {
			$out .= "
<tr>";
	}
	$out .= "<td>$icon</td>
";
	if ( in_array( "Mountain Lion", $versions ) ) {
		$out .= "<td><img src='System Icons -- Mountain Lion/images/$icon'></td>
";
	} else {
		$out .= "<td class='nil'>X</td>
";		
	}
	if ( in_array( "Mavericks", $versions ) ) {
		$out .= "<td><img src='System Icons -- Mavericks/images/$icon'></td>
";
	} else {
		$out .= "<td class='nil'>X</td>
";		
	}
	if ( in_array( "Yosemite", $versions ) ) {
		$out .= "<td><img src='System Icons -- Yosemite/images/$icon'></td>
";
	} else {
		$out .= "<td class='nil'>X</td>
";		
	}
$out .= "</tr>
";
endforeach;

$out .= "</table>
<ol>
";

foreach ( $all as $a ) {
$out .= "<li>{$a}</li>
";
}

$out .= "
</ol>
</body>
</html>";

file_put_contents( "unified.html", $out );

print_r( $all );